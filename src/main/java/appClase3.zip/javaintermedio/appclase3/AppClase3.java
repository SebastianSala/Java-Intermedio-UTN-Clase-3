package javaintermedio.appclase3;

import javaintermedio.appclase3.clases.App;

public class AppClase3 {

    public static void main(String[] args) {
      
      App app = new App();
      app.run();
    }
}
